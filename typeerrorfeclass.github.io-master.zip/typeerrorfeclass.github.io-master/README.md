# TypeError前端直播室

## 访问

* 主页: https://typeerrorfeclass.github.io
* YY直播间: [34592948](https://0x9.me/j4v80)

## 联系方式

微信扫码:

![微信二维码](./assets/wechat.png)

## 项目

### 高级前端培训课程

每周六周日线上开课, YY直播室见下方. 如需报名请加微信.

### 前端技术每话题每日直播

筹备中...